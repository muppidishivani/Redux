import axios from "axios";
export const addProduct = async (productData) => {
        try {
            const response = await axios.post(`http://localhost:8001/add`, productData, {
                
            });
            return response.data; // Return data on success
        } catch (error) {
            console.error("Error adding product:", error);
            throw error; // Propagate error for handling in component
        }
    };

export const fetchProducts = async () => {
    
        const response = await axios.get(`http://localhost:8001/products`);
        return response.data;  
    
};


export const updateProduct = async (id, updatedProductData) => {
   
        const response = await axios.put(`http://localhost:8001/update/${id}`, updatedProductData);
        return response.data;  
    
};
export const productDelete= async(id)=>
{
  const result=await axios.delete(`http://localhost:8001/delete/${id}`)
}


