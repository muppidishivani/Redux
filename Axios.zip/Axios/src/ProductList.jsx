import React, { useState } from "react";
import { fetchProducts, productDelete } from "./Service/ProductService";
import 'bootstrap/dist/css/bootstrap.min.css';

const ProductList = () => {
    const [products, setProducts] = useState([]);

    const handleFetchProducts = async () => {
        const data = await fetchProducts();
        setProducts(data);
    };

    const deleteProduct = async (id) => {
        await productDelete(id);
        const updatedProducts = products.filter(item => item.id !== id);
        setProducts(updatedProducts);
    };

    return (
        <center>
        <div>
            <h2>Product List</h2>
            <button onClick={handleFetchProducts} className="btn btn-primary mb-3">Fetch Products</button>
            {products.length > 0 ? (
                <table className="table table-bordered table-hover">
                     <thead className="bg-dark text-white">
                     <tr>
                      <th className="bg-dark text-white">ID</th>
                      <th className="bg-dark text-white">Name</th>
                      <th className="bg-dark text-white">Category</th>
                      <th className="bg-dark text-white">Price</th>
                      <th className="bg-dark text-white">Quantity</th>
                       <th className="bg-dark text-white">Image</th>
                       <th className="bg-dark text-white">Action</th>
                      </tr>
                    </thead>
                    <tbody>
                        {products.map((product) => (
                            <tr key={product.id}>
                                <td>{product.id}</td>
                                <td>{product.name}</td>
                                <td>{product.category}</td>
                                <td>${product.price}</td>
                                <td>{product.quantity}</td>
                                <td>
                                    <img 
                                        src={`/Image/${product.image}`} 
                                        alt={product.name} 
                                        width="100" 
                                        height="100" 
                                    />
                                </td>
                                <td>
                                    <button className="btn btn-success me-2" onClick={() => handleUpdateProduct(product.id)}>Update</button>
                                    <button className="btn btn-danger" onClick={() => deleteProduct(product.id)}>Delete</button>
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            ) : (
                <p>No products available</p>
            )}
        </div>
        </center>);
};

export default ProductList;
