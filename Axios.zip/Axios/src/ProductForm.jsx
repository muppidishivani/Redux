import React, { useRef } from "react";
import { addProduct } from "./Service/ProductService";
//import 'bootstrap/dist/css/bootstrap.min.css';
const ProductForm = () => {
    const nameRef = useRef(null);
    const categoryRef = useRef(null);
    const priceRef = useRef(null);
    const quantityRef = useRef(null);
    const imageRef = useRef(null); 

    const handleSubmit = async (e) => {
        e.preventDefault();

        const productData = {
            name: nameRef.current.value,
            category: categoryRef.current.value,
            price: parseFloat(priceRef.current.value),
            quantity: parseInt(quantityRef.current.value),
            image: imageRef.current.files[0] ? imageRef.current.files[0].name : null 
        };

        console.log("Product Data:", productData);

        await addProduct(productData);

       
    };

    return (
        <center>
        <div className="container mt-10">
            <h2 className="text-center mb-4">Add Product</h2>
            <form onSubmit={handleSubmit} className="p-4 border rounded bg-light ">
                <div className="mb-3">
                    <label className="form-label">Product Name:</label>
                    <input type="text" ref={nameRef} className="form-control" required />
                </div>
                <div className="mb-3">
                    <label className="form-label">Category:</label>
                    <input type="text" ref={categoryRef} className="form-control" required />
                </div>
                <div className="mb-3">
                    <label className="form-label">Price:</label>
                    <input type="number" step="0.01" ref={priceRef} className="form-control" required />
                </div>
                <div className="mb-3">
                    <label className="form-label">Quantity:</label>
                    <input type="number" ref={quantityRef} className="form-control" required />
                </div>
                <div className="mb-3">
                    <label className="form-label">Image:</label>
                    <input type="file" accept="image/*" ref={imageRef} className="form-control" />
                </div>
                <button type="submit" className="btn btn-primary w-100">Add Product</button>
            </form>
        </div>
        </center>);
};

export default ProductForm;
