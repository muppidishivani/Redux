import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import GitHubLoginComponent from './GitHUbLoginComponenet';
import { GoogleOAuthProvider } from '@react-oauth/google';
import GoogleLoginComponent from './GoogleLoginComponent';


const Home = () => (
  <div className="container py-5">
    <div className="row align-items-center">
    
      <div className="col-md-6">
      <img src="home.jpg" alt="Food Menu" class="img-fluid rounded-circle" />

      </div>

      
      <div className="col-md-6 text-center text-md-start">
        <h1 className="display-5 text-primary mb-3">Welcome to Food Menu!</h1>
        <p className="lead text-success"><i>
        Explore our tasty veg and non-veg dishes, perfect for every craving, whether light or hearty!</i></p>
        
       <GitHubLoginComponent />
       <GoogleOAuthProvider clientId="221418219215-u3j4c4am3trvvte1cptrlnp2ss9afev1.apps.googleusercontent.com">
    
    <GoogleLoginComponent />
    </GoogleOAuthProvider>
        </div>
      <div>

     
      </div>
    </div>
  </div>
);

export default Home;
