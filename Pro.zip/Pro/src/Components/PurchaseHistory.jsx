import React from 'react';
import { useSelector } from 'react-redux';

function PurchaseHistory() {
  // Access the purchase history from Redux store
  const purchaseHistory = useSelector((state) => state.purchaseHistory.history);

  return (
    <div className="container my-5">
      <h2 className="text-center mb-4">Purchase History</h2>
      {purchaseHistory.length === 0 ? (
        <p className="text-center">No past purchases available.</p>
      ) : (
        <div className="list-group">
          {purchaseHistory.map((purchase, index) => (
            <div key={index} className="list-group-item mb-4">
              <h4 className="mb-3">Purchase on: {purchase.date}</h4>
              <p><strong>Total Amount:</strong> ${purchase.totalAmount.toFixed(2)}</p>
              <h5 className="mt-3">Items:</h5>
              <ul className="list-group list-group-flush">
                {purchase.items.map((item, itemIndex) => (
                  <li key={itemIndex} className="list-group-item">
                    <p><strong>Product:</strong> {item.name}</p>
                    <p><strong>Price per item:</strong> ${item.price.toFixed(2)}</p>
                    <p><strong>Quantity:</strong> {item.quantity}</p>
                    <p><strong>Total for this item:</strong> ${(item.price * item.quantity).toFixed(2)}</p>
                  </li>
                ))}
              </ul>
              <hr />
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

export default PurchaseHistory;
