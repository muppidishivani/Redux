import React, { useEffect } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { addToCart, fetchItems } from '../Store';
import 'bootstrap/dist/css/bootstrap.min.css';


const VegItems = () => {
  // Assuming VegItems are fetched and stored in the Redux store
  const VegItems = useSelector((state) => state.items.veg);
  const dispatch = useDispatch();

  useEffect(() => {
    dispatch(fetchItems());
  }, [dispatch]);

  const handleAddToCart = (item) => {
    dispatch(addToCart(item));
  };

  return (
    <div className="container my-5"><br></br>
      <h2 className="text-center mb-5 text-info">Vegetarian Menu</h2>
      <div className="row row-cols-1 row-cols-md-2 row-cols-lg-3 g-0 justify-content-center">
        {VegItems.length > 0 ? (
          VegItems.map((item) => (
            <div key={item.id} className="col d-flex justify-content-center">
              <div className="card h-100 shadow-sm border-0 " >
               
                <img
                  src={`/Image/${item.image}`}
                  alt={item.name}
                  className="card-img-top img-fluid rounded-3"
                  style={{ height: '210px', width: '300px', objectFit: 'cover' }} // Smaller image size
                />
                <div className="card-body d-flex flex-column">
                  <h5 className="card-title text-truncate">{item.name}</h5>
                  <p className="card-text flex-grow-1">
                    <strong>Price:</strong> ${item.price.toFixed(2)}
                  </p>
                  <button
                    onClick={() => handleAddToCart(item)}
                    className="btn btn-primary mt-auto w-75 mx-auto btn-hover"
                  >
                    Add to Cart
                  </button>
                </div>
              </div>
            </div>
          ))
        ) : (
          <div className="col-12 text-center">
            <p>No vegetarian items available.</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default VegItems;
