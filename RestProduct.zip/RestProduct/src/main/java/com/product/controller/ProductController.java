package com.product.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.product.model.Product;
import com.product.service.ProductService;

@RestController
public class ProductController {

	@Autowired ProductService service;
	@PostMapping("/product")
	public Product saveData(@RequestBody Product product)
	{
		return service.saveproduct(product);
	}
	@GetMapping("/get")
	public List<Product> getProduct()
	{
		return service.getData();
	}
}
